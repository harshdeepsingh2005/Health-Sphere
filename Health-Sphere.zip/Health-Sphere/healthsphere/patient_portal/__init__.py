"""
HealthSphere AI - Patient Portal App
====================================

Patient-facing portal for health management and appointments.
"""

default_app_config = 'patient_portal.apps.PatientPortalConfig'
