"""
HealthSphere AI - Admin Portal App
==================================

Hospital administration portal for managing resources, staff, and analytics.
"""

default_app_config = 'admin_portal.apps.AdminPortalConfig'
