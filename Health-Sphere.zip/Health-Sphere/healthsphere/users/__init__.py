"""
HealthSphere AI - Users App
===========================

This app handles user authentication, roles, and profile management.
"""

# This makes the app a Python package
default_app_config = 'users.apps.UsersConfig'
