"""
HealthSphere AI - Clinical Portal App
=====================================

Clinical portal for doctors and nurses to manage patient care.
"""

default_app_config = 'clinical_portal.apps.ClinicalPortalConfig'
