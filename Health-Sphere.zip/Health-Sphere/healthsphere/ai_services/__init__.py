"""
HealthSphere AI - AI Services App
=================================

Simulated AI/ML services for healthcare predictions and analysis.
These are placeholder implementations for academic demonstration.
"""

default_app_config = 'ai_services.apps.AiServicesConfig'
