"""
HealthSphere AI - Configuration Package
=======================================

This package contains Django project configuration files.
"""
